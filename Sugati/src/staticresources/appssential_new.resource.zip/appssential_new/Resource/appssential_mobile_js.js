jQuery(document).ready(function($){
	$('body.homeTab .bPageBlock .pbTitle').siblings().remove();

	$('.btn-minimise').click(function(event){
		event.preventDefault();
		$(this).toggleClass('up').parents('.box-top').toggleClass('collapsed').siblings('.box-body').toggle();
	});

});

