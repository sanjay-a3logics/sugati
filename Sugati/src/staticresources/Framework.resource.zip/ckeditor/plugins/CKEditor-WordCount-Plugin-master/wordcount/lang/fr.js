﻿// French Translation by Nicolas M.

CKEDITOR.plugins.setLang('wordcount', 'fr', {
    WordCount: 'Mots:',
    CharCount: 'Caractères:',
    CharCountWithHTML: 'Caractères (including HTML):',
    limit: 'Limite:',
    title: 'Statistiques'
});
